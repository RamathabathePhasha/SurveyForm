window.onload = function() {
  document.getElementById("pageTitle").innerHTML = "Welcome";
}

function submitForm() {
  const name = document.getElementById("name").value;
  const surname = document.getElementById("surname").value;
  const age = document.getElementById("age").value;
  const sport = document.querySelector('input[name="sport"]:checked').value;
  const watch = document.getElementById("watch").value;
  const play = document.getElementById("play").value;
  const person = document.getElementById("person").value;
  const optional = document.getElementById("optional").value;

  console.log("Name: " + name);
  console.log("Surname: " + surname);
  console.log("Age: " + age);
  console.log("Favorite type of sport: " + sport);
  console.log("Favorite Sport to watch: " + watch);
  console.log("Favorite Sport to play: " + play);
  console.log("Favorite Sports-person: " + person);
  console.log("Your thoughts on Sports: " + optional);

  document.getElementById("pageTitle").innerHTML = "Thank you for your submission!";
  alert("Name: " + name + "\nSurname: " + surname + "\nAge: " + age + "\nFavorite type of sport: " + sport + "\nFavorite Sport to watch: " + watch + "\nFavorite Sport to play: " + play + "\nFavorite Sports-person: " + person + "\nYour thoughts on Sports: " + optional);
}
